/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javadb;

/**
 *
 * @author S525037
// */
//public class GenerateQRCode {
//    
//}

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Hashtable;

import javax.imageio.ImageIO;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class GenerateQRCode {

	/**
	 * @param args
	 * @throws WriterException
	 * @throws IOException
	 */
	public static void main(String[] args) throws WriterException, IOException {
                //Colden Hall
	        //String file = "C:\\ColdenHall.jpg";	
                String qrCodeText = "Colden Hall \n";
//                        + "Purpose :</b> Office/Classroom\n" +
//                        " Total Sq. Ft. :78,145\n" +
//                        "Year Built:</b> 1957\n" +
//                        "Floorplans View PDF: \n"
//                        + "1st Floor http://www.nwmissouri.edu/services/facility/pdf/floorplans/Colden%20Hall%201st%20Floor.pdf \n"
//                        + "2nd Floor http://www.nwmissouri.edu/services/facility/pdf/floorplans/Colden%20Hall%202nd%20Floor.pdf \n"
//                        + "3rd Floor http://www.nwmissouri.edu/services/facility/pdf/floorplans/Colden%20Hall%203rd%20Floor.pdf \n"
//                        +" To know more please click here: </b> \n http://www.nwmissouri.edu/services/facility/buildings/# ";
                String filePath = "C:\\ColdenHall.jpg";
		int size = 125;
		String fileType = "jpg";
		File qrFile = new File(filePath);
		createQRImage(qrFile, qrCodeText, size, fileType);
               // Student union
               // String file1 = "C:\\StudentUnion.jpg";	
               String qrCodeText1 = " <b>Student Union\n";
//                       +"Purpose: Office/General Use\n" +
//                        "Total Sq. Ft.: 113,653\n" +
//                        "Year Built: 1950\n" +
//                        "Floorplans View PDF:\n"
//                        + "1st Floor : http://www.nwmissouri.edu/services/facility/pdf/floorplans/Union1F.pdf \n"
//                        + "2nd Floor : http://www.nwmissouri.edu/services/facility/pdf/floorplans/Union2F.pdf \n"
//                        + "3rd Floor : http://www.nwmissouri.edu/services/facility/pdf/floorplans/Union3F.pdf \n"+
//                        "<b> To know more please click here:<b> http://www.nwmissouri.edu/services/facility/buildings/#";
                String filePath1 = "C:\\Student union.jpg";
		int size1 = 125;
		String fileType1 = "jpg";
		File qrFile1 = new File(filePath1);
		createQRImage(qrFile1, qrCodeText1, size1, fileType1);
                
                 // Valk Center
                String qrCodeText2 = "Valk Center \n";     
                String filePath2 = "C:\\ValkCenter.jpg";
		int size2 = 125;
		String fileType2 = "jpg";
		File qrFile2 = new File(filePath2);
		createQRImage(qrFile2, qrCodeText2, size2, fileType2);
                
                // Admin Building
                String qrCodeText3 = "Admin Building \n";     
                String filePath3 = "C:\\AdminBuilding.jpg";
		int size3 = 125;
		String fileType3 = "jpg";
		File qrFile3 = new File(filePath3);
		createQRImage(qrFile3, qrCodeText3, size3, fileType3);
                
                //Garett Strong
                String qrCodeText4 = "Garett Strong \n";     
                String filePath4 = "C:\\GarettStrong.jpg";
		int size4 = 125;
		String fileType4 = "jpg";
		File qrFile4 = new File(filePath4);
		createQRImage(qrFile4, qrCodeText4, size4, fileType4);
                
                 //B.D. Owens Library
                String qrCodeText5 = "B.D. Owens Library \n";     
                String filePath5 = "C:\\B.D.OwensLibrary.jpg";
		int size5 = 125;
		String fileType5 = "jpg";
		File qrFile5 = new File(filePath5);
		createQRImage(qrFile5, qrCodeText5, size5, fileType5);
                
                //Station
                String qrCodeText6 = "Station \n";     
                String filePath6 = "C:\\Station.jpg";
		int size6 = 125;
		String fileType6 = "jpg";
		File qrFile6 = new File(filePath6);
		createQRImage(qrFile6, qrCodeText6, size6, fileType6);
                
                              
                //Lamkin Activity Center
                String qrCodeText7 = "Lamkin Activity Center \n";     
                String filePath7 = "C:\\LamkinActivityCenter.jpg";
		int size7 = 125;
		String fileType7 = "jpg";
		File qrFile7 = new File(filePath7);
		createQRImage(qrFile7, qrCodeText7, size7, fileType7);
                
                //Fine Arts Center
                String qrCodeText8 = "Fine Arts Center \n";     
                String filePath8 = "C:\\FineArtsCenter.jpg";
		int size8 = 125;
		String fileType8 = "jpg";
		File qrFile8 = new File(filePath8);
		createQRImage(qrFile8, qrCodeText8, size8, fileType8);
                
                //Recreation Center
                String qrCodeText9 = "Recreation Center \n";     
                String filePath9 = "C:\\RecreationCenter.jpg";
		int size9 = 125;
		String fileType9 = "jpg";
		File qrFile9 = new File(filePath9);
		createQRImage(qrFile9, qrCodeText9, size9, fileType9);
                
                
		System.out.println("DONE");
	}

	private static void createQRImage(File qrFile, String qrCodeText, int size,
			String fileType) throws WriterException, IOException {
		// Create the ByteMatrix for the QR-Code that encodes the given String
		Hashtable hintMap = new Hashtable();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		BitMatrix byteMatrix = qrCodeWriter.encode(qrCodeText,
				BarcodeFormat.QR_CODE, size, size, hintMap);
		// Make the BufferedImage that are to hold the QRCode
		int matrixWidth = byteMatrix.getWidth();
		BufferedImage image = new BufferedImage(matrixWidth, matrixWidth,
				BufferedImage.TYPE_INT_RGB);
		image.createGraphics();

		Graphics2D graphics = (Graphics2D) image.getGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, matrixWidth, matrixWidth);
		// Paint and save the image using the ByteMatrix
		graphics.setColor(Color.BLACK);

		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixWidth; j++) {
				if (byteMatrix.get(i, j)) {
					graphics.fillRect(i, j, 1, 1);
				}
			}
		}
		ImageIO.write(image, fileType, qrFile);
	}

}
 